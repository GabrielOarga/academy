//
//  FirstViewController.swift
//  Rushes IOS
//
//  Created by Gabriel Oarga on 13/02/16.
//  Copyright © 2016 goarga-azaha. All rights reserved.
//

import UIKit
import MapKit

class FirstViewController: UIViewController {

    @IBOutlet var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.mapType = MKMapType.Hybrid
        let location = CLLocationCoordinate2D(latitude: 46.78587, longitude: 23.607644)
        let annotation = MKPointAnnotation()
        let span = MKCoordinateSpanMake(0.004, 0.004)
        let region = MKCoordinateRegion(center: location, span: span)
        mapView.setRegion(region, animated: true)
        annotation.coordinate = location
        annotation.title = "Academy+Plus"
        annotation.subtitle = "42 is love 42 is life"
        mapView.addAnnotation(annotation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}