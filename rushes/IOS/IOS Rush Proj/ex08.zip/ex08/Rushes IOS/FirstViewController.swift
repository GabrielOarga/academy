//
//  FirstViewController.swift
//  Rushes IOS
//
//  Created by Gabriel Oarga on 13/02/16.
//  Copyright © 2016 goarga-azaha. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class FirstViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let location = CLLocationCoordinate2D(latitude: 46.78587, longitude: 23.607644)
        let annotation = MKPointAnnotation()
        let span = MKCoordinateSpanMake(0.004, 0.004)
        let region = MKCoordinateRegion(center: location, span: span)
        mapView.setRegion(region, animated: true)
        annotation.coordinate = location
        annotation.title = "Academy+Plus"
        annotation.subtitle = "42 is love 42 is life"
        mapView.addAnnotation(annotation)
        
    }
    
    @IBAction func LocateMe(sender: AnyObject) {
    
        var manager:CLLocationManager!

        manager = CLLocationManager()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestAlwaysAuthorization()
        manager.startUpdatingLocation()
        
        mapView.delegate = self
        mapView.showsUserLocation = true
        
        if (mapView.userLocation.coordinate.longitude > 0.2)
        {
            
        let location = mapView.userLocation
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004))
        self.mapView.setRegion(region, animated: true)
        }
    }
    
    

    @IBAction func SegmentControl(sender: AnyObject) {
        switch sender.selectedSegmentIndex {
            
        case 0:
            mapView.mapType = MKMapType.Standard
            
        case 1:
            mapView.mapType = MKMapType.Satellite
            
        case 2:
            mapView.mapType = MKMapType.Hybrid
            
        default:
            mapView.mapType = MKMapType.Standard
        }
    }
}