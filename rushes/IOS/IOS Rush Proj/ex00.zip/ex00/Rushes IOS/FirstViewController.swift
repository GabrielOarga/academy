//
//  FirstViewController.swift
//  Rushes IOS
//
//  Created by Gabriel Oarga on 13/02/16.
//  Copyright © 2016 goarga-azaha. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

