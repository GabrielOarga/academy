//
//  FirstViewController.swift
//  Rushes IOS
//
//  Created by Gabriel Oarga on 13/02/16.
//  Copyright © 2016 goarga-azaha. All rights reserved.
//

import UIKit
import MapKit

class FirstViewController: UIViewController {

    @IBOutlet var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        let location = CLLocationCoordinate2D(latitude: 46.78587, longitude: 23.607644)
        let annotation = MKPointAnnotation()
        let span = MKCoordinateSpanMake(0.004, 0.004)
        let region = MKCoordinateRegion(center: location, span: span)
        mapView.setRegion(region, animated: true)
        annotation.coordinate = location
        annotation.title = "Academy+Plus"
        annotation.subtitle = "42 is love 42 is life"
        mapView.addAnnotation(annotation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func SegmentControl(sender: AnyObject) {
        switch sender.selectedSegmentIndex {
            
        case 0:
            mapView.mapType = MKMapType.Standard
            
        case 1:
            mapView.mapType = MKMapType.Satellite
            
        case 2:
            mapView.mapType = MKMapType.Hybrid
            
        default:
            mapView.mapType = MKMapType.Standard
        }
    }
}